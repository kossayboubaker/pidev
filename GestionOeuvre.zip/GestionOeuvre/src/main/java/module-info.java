module tn.esprit.gestionoeuvre {
    requires javafx.controls;
    requires javafx.fxml;
    requires stripe.java;
    requires com.google.zxing;
    requires twilio;
    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;
    requires com.google.zxing.javase;
    opens tn.esprit.gestionoeuvre.controller to javafx.fxml;
    exports tn.esprit.gestionoeuvre.entity;
    opens tn.esprit.gestionoeuvre to javafx.fxml;
    exports tn.esprit.gestionoeuvre;
}